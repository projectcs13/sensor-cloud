forecast
========

forecast package for R

This is a pre-release version. The released version is on CRAN at http://cran.r-project.org/package=forecast
